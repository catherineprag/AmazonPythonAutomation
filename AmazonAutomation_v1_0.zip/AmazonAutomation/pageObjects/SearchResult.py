from selenium.webdriver.remote.webelement import *
from selenium.webdriver.support.wait import *
from selenium.webdriver.support import expected_conditions as EC
from helpers.ElementLocatorHelpers import ElementLocatorHelpers
from helpers.FileHandler import FileHandler

class SearchResult:

    def __init__(self, driver):
        #Locators for the SearchResult page
        self.driver = driver
        self.paperBackCheck = "// *[text() = 'Paperback']"
        self.seeMoreClick="// div[ @ id = 'departments'] // *[text() = 'See more']"
        self.subDept="//div[@id ='departments']//*[text()='Arts, Film & Photography']"
        self.nextSubDept="//div[@id='departments']//*[text()='Cinema & Broadcast']"
        self.maxRate="(//i[@class='a-icon a-icon-star-medium a-star-medium-4'])"
        self.lowPrice="//input[@name='low-price']"
        self.maxPrice="//input[@name='high-price']"
        self.go="//span[contains(text(),'Go') and @id='a-autoid-1-announce']"
        self.paperKinderCheck="//*[text()='Kindle eBooks']"
        self.paperHardCoverCheck="//*[text()='Hardcover']"
        self.panel="//*[@id='s-refinements']"
        self.bookTitle="(//div[@class='s-include-content-margin s-border-bottom'])[1]//a[@class='a-link-normal a-text-normal']//span"
        self.price1="//div[@class='a-section a-spacing-none a-spacing-top-small']//a[@class='a-size-base a-link-normal s-no-hover a-text-normal']//span[@class='a-price']//span[@class='a-price-whole']"
        self.price2="//div[@class='a-section a-spacing-none a-spacing-top-mini']//span[@class='a-price']//span[@class='a-price-whole']"
        self.price3="//div[@class='a-row a-size-base a-color-secondary']//span[@class='a-color-price']"
        self.format1="//div[@class='a-section a-spacing-none a-spacing-top-small']//a[@class='a-size-base a-link-normal a-text-bold']"
        self.format2="//div[@class='a-row a-spacing-mini'][1]//a[@class='a-size-base a-link-normal a-text-bold']"
        self.format3="//div[@class='a-row a-spacing-mini'][2]//a[@class='a-size-base a-link-normal a-text-bold']"
        self.delieveryyclick = "//span[contains(text(),'Select your address')]"
        self.pincodeinput = "GLUXZipUpdateInput"
        self.pincodesubmit = "//span[@id='GLUXZipUpdate']"

    def selecting_sub_departments(self,driver):
        # Choose Arts, Film & Photography department
        # Choose Cinema & Broadcast as sub-department
        #The Book should be available in all three formats like paperback, Kindle ebooks, and Hardcover. Apply those necessary filters
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementClick(driver, "xpath", self.paperBackCheck)
        time.sleep(1)
        elementLocatorHelper.elementClick(driver, "xpath", self.seeMoreClick)
        elementLocatorHelper.elementClick(driver, "xpath", self.subDept)
        time.sleep(1)
        elementLocatorHelper.elementClick(driver, "xpath", self.seeMoreClick)
        elementLocatorHelper.elementClick(driver, "xpath", self.nextSubDept)
        elementLocatorHelper.elementClick(driver, "xpath", self.paperKinderCheck)
        elementLocatorHelper.elementClick(driver, "xpath", self.paperHardCoverCheck)

    def selecting_high_rating(self,driver):
        #Choose the Max of “Avg Customer Review” option
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementClick(driver, "xpath", self.maxRate)

    def priceSelector(self,driver,maxPrice,minPrice):
        #Make a filter of price with Maximum 1000 rupees and Minimum of 1500 Rupees
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementsendKey(driver, "xpath", self.maxPrice,maxPrice)
        elementLocatorHelper.elementsendKey(driver, "xpath", self.lowPrice, minPrice)
        time.sleep(2)
        elementLocatorHelper.elementSubmit(driver, "xpath", self.go)
        time.sleep(1)

    def storeResult(self,driver):
        #Choose the first test result (first product listed on the search result page) and read/record as many details related to that particular test result as possible.
        #Title of the book
        #Price of the book for different editions
        #Product details
        elementLocatorHelper = ElementLocatorHelpers(self)
        title=elementLocatorHelper.getText(driver,"xpath",self.bookTitle)
        bookformat1 = elementLocatorHelper.getText(driver, "xpath", self.format1)
        bookformat2= elementLocatorHelper.getText(driver, "xpath", self.format2)
        bookformat3= elementLocatorHelper.getText(driver, "xpath", self.format3)
        bookprice1 = elementLocatorHelper.getText(driver, "xpath", self.price1)
        bookprice2 = elementLocatorHelper.getText(driver, "xpath", self.price2)
        bookprice3 = elementLocatorHelper.getText(driver, "xpath", self.price3).replace('₹', '')
        print("READING TITLE FROM TEST1"+title)
        print("READING TITLE FROM BOOK FORMAT: " + bookformat1 + "READING PRICE: " + bookprice1)
        print("READING TITLE FROM BOOK FORMAT: " + bookformat2 + "READING PRICE: " + bookprice2)
        print("READING TITLE FROM BOOK FORMAT: " + bookformat3 + "READING PRICE: " + bookprice3)
        expectedvalue=title+" : "+bookformat1+"-"+bookprice1+" ; "+bookformat2+"-"+bookprice2 +";"+ bookformat3+"-"+bookprice3
        print("PRINTING THE LIST" + expectedvalue)
        file_handler=FileHandler(self);
        list=[expectedvalue]
        file_handler.write_into_file(self,list)

    def validateResult(self,driver):
        #Validating the stored result with actual
        elementLocatorHelper = ElementLocatorHelpers(self)
        file_handler=FileHandler(self);
        list=file_handler.read_from_file(self);
        title = elementLocatorHelper.getText(driver, "xpath", self.bookTitle)
        bookformat1 = elementLocatorHelper.getText(driver, "xpath", self.format1)
        bookformat2 = elementLocatorHelper.getText(driver, "xpath", self.format2)
        bookformat3 = elementLocatorHelper.getText(driver, "xpath", self.format3)
        bookprice1 = elementLocatorHelper.getText(driver, "xpath", self.price1)
        bookprice2 = elementLocatorHelper.getText(driver, "xpath", self.price2)
        bookprice3 = elementLocatorHelper.getText(driver, "xpath", self.price3).replace('₹', '')
        print("READING TITLE FROM TEST2" + title)
        print("READING TITLE FROM BOOK FORMAT: " + bookformat1 + "READING PRICE: " + bookprice1)
        print("READING TITLE FROM BOOK FORMAT: " + bookformat2 + "READING PRICE: " + bookprice2)
        print("READING TITLE FROM BOOK FORMAT: " + bookformat3 + "READING PRICE: " + bookprice3)
        actualValue=title + " : " + bookformat1 + "-" + bookprice1 + " ; " + bookformat2 + "-" + bookprice2 + ";" + bookformat3 + "-" + bookprice3
        assert actualValue==list[0],"Stored values doees not match"

    def enter_delivery_location(self,driver,pincode):
        #Delivery of the product should be to the Pincode 600001
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementClick(driver, "xpath", self.delieveryyclick)
        time.sleep(1)
        elementLocatorHelper.elementsendKey(driver, "id", self.pincodeinput,pincode)
        elementLocatorHelper.elementClick(driver, "xpath", self.pincodesubmit)
