from selenium.webdriver.remote.webelement import *
from selenium.webdriver.support.wait import *
from selenium.webdriver.support import expected_conditions as EC
from helpers.ElementLocatorHelpers import ElementLocatorHelpers

class HomeScreen:

    def __init__(self, driver):
        #Locators for Home screen page
        self.driver = driver
        self.title = WebDriverWait(self.driver.instance, 50).until(
            EC.visibility_of_element_located((
                By.XPATH, "//a[@href='/ref=nav_logo']")))
        self.mySelectElement = "searchDropdownBox"
        self.selected="//option[@selected='selected']"
        self.searchBox = "//input[@id='twotabsearchtextbox']"


    def validate_title_is_present(self,driver):
        assert self.title.is_displayed()



    def search_by_department(self, driver,option):
        #Req: In the search dropdown list, choose the ‘Books’ option.

        elementLocatorHelper = ElementLocatorHelpers(self)
        print("Selecting option " + option)
        if option=="Books":
            elementLocatorHelper.elementsendKey(driver, "id", self.mySelectElement, "b")
            elementLocatorHelper.elementsendKey(driver, "id", self.mySelectElement, "b")
            elementLocatorHelper.elementsendKey(driver, "id", self.mySelectElement, "b")

    def search_by_item(self, driver, item):
        # Enter search text ‘artificial intelligence’ and search.
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementsendKey(driver, "xpath", self.searchBox, item)
        elementLocatorHelper.elementSubmit(driver, "xpath", self.searchBox)
