import unittest

from webdriver import Driver
from values import strings
from pageObjects.HomeScreen import HomeScreen
from pageObjects.SearchResult import SearchResult

class TestBooksFilterRecorder(unittest.TestCase):

    #Testdata for test
    department ="Books"
    item='Artificial Intelligence'
    maxPrice=1500
    minPrice=1000
    pincode=600001

    #To intiate firefox driver
    def setUp(self):
        self.driver = Driver()
        self.driver.navigate(strings.base_url)

    #To record search result to file "resultStorage.txt"
    def test_Amazon_Recorder(self):
        home_screen = HomeScreen(self.driver)
        search_results=SearchResult(self.driver)
        home_screen.validate_title_is_present(self)
        home_screen.search_by_department(self.driver,self.department)
        home_screen.search_by_item(self.driver,self.item)
        search_results.selecting_sub_departments(self.driver)
        search_results.selecting_high_rating(self.driver)
        search_results.priceSelector(self.driver,self.maxPrice,self.minPrice)
        search_results.storeResult(self.driver);
        search_results.enter_delivery_location(self.driver, self.pincode)

    #To validate stored result with below test
    def test_Amazon_Validator(self):
        home_screen = HomeScreen(self.driver)
        search_results = SearchResult(self.driver)
        home_screen.validate_title_is_present(self)
        home_screen.search_by_department(self.driver, self.department)
        home_screen.search_by_item(self.driver, self.item)
        search_results.selecting_sub_departments(self.driver)
        search_results.selecting_high_rating(self.driver)
        search_results.priceSelector(self.driver, self.maxPrice, self.minPrice)
        search_results.validateResult(self.driver);
        search_results.enter_delivery_location(self.driver, self.pincode)

    #To close the running browser
    def tearDown(self):
        self.driver.instance.quit()