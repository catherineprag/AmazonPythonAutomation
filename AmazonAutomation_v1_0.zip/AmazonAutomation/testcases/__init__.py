from webdriver import Driver
from selenium.webdriver.remote.webelement import *
from selenium.webdriver.support.wait import *
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select


from selenium.webdriver.common.action_chains import ActionChains


class HomeScreen:


    # title =  (By.XPATH, "//a[@href='/ref=nav_logo']")
    # mySelectElement = (By.CLASS_NAME,"searchDropdownBox")
    # dropDownButton = (By.XPATH, '//select[@id=\'searchDropdownBox\']')
    # searchTextBox=(By.XPATH,"//input[@id='twotabsearchtextbox']")

    def __init__(self, driver):
        self.driver = driver
        # self.

        title = WebDriverWait(self.driver.instance, 30).until(
            EC.visibility_of_element_located((
                By.XPATH, "//a[@href='/ref=nav_logo']")))

        # self.optiondropdown =WebDriverWait(self.driver.instance, 120).until(
        #     EC.visibility_of_element_located((
        #         By.XPATH, "//select[@id='searchDropdownBox']")))
        #
        # self.bookoption=WebDriverWait(self.driver.instance, 60).until(
        #     EC.visibility_of_element_located((
        #         By.XPATH, "//select[@class='nav-search-dropdown searchSelect']//option[@value='search-alias=stripbooks']")))


    def validate_title_is_present(self,driver):
        self.driver=driver
        assert self.title.is_displayed()



    # def search_by_department(self, option):
    #     WebDriverWait(self.driver.instance, 50).until(
    #         EC.visibility_of_element_located(self.mySelectElement))
    #     self.mySelectElement.send_keys('Books')
    #
    #     WebDriverWait(self.driver.instance, 30).until(
    #         EC.visibility_of_element_located(self.mySelectElement))
    #     self.mySelectElement.send_keys('Books')
    #



#def click_Option_fromDropDown(self, driver, option):


#def click_Option_fromDropDown(self,driver,option):
# self=driver.instance
        # mySelectElement=self.find_element_by_xpath("//select[@id='searchDropdownBox']")
        # dropDownMenu = Select(self,mySelectElement)
        #
        # dropDownMenu.select_by_value("Books")
        # WebDriverWait(self.driver.instance, 60).until(EC.element_to_be_clickable(
        #     (By.XPATH, "//select[@id='searchDropdownBox']//options[contains(.,'"+option+"')]")))
        # dropDownMenu.select_by_visible_text(''+option+'')

        # self.driver.instance.dropDownButton.click()

        # self.driver = driver
        # element = self.driver.find_element(self.driver,self.dropDownButton)
        # element.click()

    # self.driver = driver
        # assert self.optiondropdown.is_displayed()
        # assert self.driver.find_element_by_xpath("//select[@id='searchDropdownBox']").is_displayed()
        # actions.click(self.driver.find_element_by_xpath("//select[@id='searchDropdownBox']")).perform()
        # {
        #     'Books':actions.click(self.driver.find_element_by_xpath(self.find_element_by_xpath("//select[@id='searchDropdownBox']"))).perform()
        # }






