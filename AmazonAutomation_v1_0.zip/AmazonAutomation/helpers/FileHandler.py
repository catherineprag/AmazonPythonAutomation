import os


class FileHandler:

    def __init__(self,driver):
        self.driver=driver
        print()

    def write_into_file(self,driver,list):
        print ("WRITING INTO FILE PATH"+os.path.abspath("resultStorage.txt"))
        inputfile = open("resultStorage.txt", "w")
        inputfile.writelines(list)
        inputfile.close()

    def read_from_file(self,driver):
        print("READING FROM FILE PATH" + os.path.abspath("resultStorage.txt"))
        outputfile = open(os.path.abspath("resultStorage.txt"), "r+")
        list = []
        for line in outputfile:
            list.append(line)
        outputfile.close()
        return list


