from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait

class ElementLocatorHelpers:
    def __init__(self,driver):
        print()

    def elementClick(self, driver, id, path):
        self.driver = driver
        if id == "id":
            WebDriverWait(self.driver.instance, 80).until(
            EC.presence_of_element_located((By.ID, path)))
            self.driver.instance.find_element_by_id(path).click();
        elif id == "xpath":
            WebDriverWait(self.driver.instance, 80).until(
            EC.presence_of_element_located((By.XPATH, path)))
            self.driver.instance.find_element_by_xpath(path).click();


    def elementSubmit(self, driver, id, path):
        self.driver = driver
        if id == "id":
            WebDriverWait(self.driver.instance, 50).until(
            EC.presence_of_element_located((By.ID, path)))
            self.driver.instance.find_element_by_id(path).submit()

        elif id == "xpath":
                WebDriverWait(self.driver.instance, 50).until(
                    EC.presence_of_element_located((By.XPATH, path)))
                self.driver.instance.find_element_by_xpath(path).submit()

    def getText(self, driver, id, path):
        self.driver = driver
        if id == "id":
            WebDriverWait(self.driver.instance, 50).until(
            EC.presence_of_element_located((By.ID, path)))
            returnText=self.driver.instance.find_element_by_id(path).text
        elif id == "xpath":
            WebDriverWait(self.driver.instance, 50).until(
            EC.presence_of_element_located((By.XPATH, path)))
            returnText=self.driver.instance.find_element_by_xpath(path).text
        return returnText

    def elementsendKey(self, driver, id, path, option):
        self.driver = driver
        if id == "id":
            WebDriverWait(self.driver.instance, 50).until(
            EC.presence_of_element_located((By.ID, path)))
            self.driver.instance.find_element_by_id(path).send_keys(option)
        elif id == "xpath":
                WebDriverWait(self.driver.instance, 50).until(
                    EC.presence_of_element_located((By.XPATH, path)))
                self.driver.instance.find_element_by_xpath(path).send_keys(option)


