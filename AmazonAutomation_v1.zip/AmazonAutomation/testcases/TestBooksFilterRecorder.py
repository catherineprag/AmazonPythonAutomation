import unittest

import selenium
from selenium.webdriver.common.action_chains import ActionChains

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from webdriver import Driver
from values import strings
from pageObjects.HomeScreen import HomeScreen
from pageObjects.SearchResult import SearchResult
from selenium.webdriver.support.select import Select
from selenium.webdriver.remote.webelement import *
from selenium.webdriver.support.wait import *
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select


class TestBooksFilterRecorder(unittest.TestCase):

    department ="Books"
    item='Artificial Intelligence'
    maxPrice=1500
    minPrice=1000
    pincode=600001
    def setUp(self):
        self.driver = Driver()
        self.driver.navigate(strings.base_url)

    def test_Amazon_Recorder(self):
        home_screen = HomeScreen(self.driver)
        search_results=SearchResult(self.driver)
        home_screen.validate_title_is_present(self)
        home_screen.enter_delivery_location(self.driver,self.pincode)
        home_screen.search_by_department(self.driver,self.department)
        home_screen.search_by_item(self.driver,self.item)
        search_results.selecting_sub_departments(self.driver)
        search_results.selecting_high_rating(self.driver)
        search_results.priceSelector(self.driver,self.maxPrice,self.minPrice)
        search_results.storeResult(self.driver);

    def test_Amazon_Validator(self):
        home_screen = HomeScreen(self.driver)
        search_results = SearchResult(self.driver)
        home_screen.validate_title_is_present(self)
        home_screen.search_by_department(self.driver, self.department)
        home_screen.search_by_item(self.driver, self.item)
        search_results.selecting_sub_departments(self.driver)
        search_results.selecting_high_rating(self.driver)
        search_results.priceSelector(self.driver, self.maxPrice, self.minPrice)
        search_results.validateResult(self.driver);


    def tearDown(self):
        self.driver.instance.quit()


