class strings:

        base_url = "https://www.amazon.in/"