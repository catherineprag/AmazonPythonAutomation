from selenium.webdriver.remote.webelement import *
from selenium.webdriver.support.wait import *
from selenium.webdriver.support import expected_conditions as EC
from helpers.ElementLocatorHelpers import ElementLocatorHelpers

class HomeScreen:

    def __init__(self, driver):
        self.driver = driver
        self.title = WebDriverWait(self.driver.instance, 50).until(
            EC.visibility_of_element_located((
                By.XPATH, "//a[@href='/ref=nav_logo']")))
        self.mySelectElement = "searchDropdownBox"
        self.selected="//option[@selected='selected']"
        self.searchBox = "//input[@id='twotabsearchtextbox']"
        self.delieveryyclick="//span[contains(text(),'Select your address')]"
        self.pincodeinput="GLUXZipUpdateInput"
        self.pincodesubmit="//span[@id='GLUXZipUpdate']"
        # self.pincodesubmit="//input[@aria-labelledby='GLUXZipUpdate-announce']"

    def validate_title_is_present(self,driver):
        assert self.title.is_displayed()

    def enter_delivery_location(self,driver,pincode):
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementClick(driver, "xpath", self.delieveryyclick)
        elementLocatorHelper.elementsendKey(driver, "id", self.pincodeinput,pincode)
        elementLocatorHelper.elementClick(driver, "xpath", self.pincodesubmit)
        # elementLocatorHelper.elementSubmit(driver, "xpath", self.pincodesubmit)
        # elementLocatorHelper.elementClick(driver, "xpath", self.delieveryyclick)


    def search_by_department(self, driver,option):
        elementLocatorHelper = ElementLocatorHelpers(self)
        print("Selecting option " + option)
        if option=="Books":
            elementLocatorHelper.elementsendKey(driver, "id", self.mySelectElement, "b")
            elementLocatorHelper.elementsendKey(driver, "id", self.mySelectElement, "b")
            elementLocatorHelper.elementsendKey(driver, "id", self.mySelectElement, "b")

    def search_by_item(self, driver, item):
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementsendKey(driver, "xpath", self.searchBox, item)
        elementLocatorHelper.elementSubmit(driver, "xpath", self.searchBox)
