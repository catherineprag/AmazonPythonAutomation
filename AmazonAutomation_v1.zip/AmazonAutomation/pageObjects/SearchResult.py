from selenium.webdriver.remote.webelement import *
from selenium.webdriver.support.wait import *
from selenium.webdriver.support import expected_conditions as EC
from helpers.ElementLocatorHelpers import ElementLocatorHelpers
from helpers.FileHandler import FileHandler

class SearchResult:

    def __init__(self, driver):
        self.driver = driver
        self.paperBackCheck = "// *[text() = 'Paperback']"
        self.seeMoreClick="// div[ @ id = 'departments'] // *[text() = 'See more']"
        self.subDept="//div[@id ='departments']//*[text()='Arts, Film & Photography']"
        self.nextSubDept="//div[@id='departments']//*[text()='Cinema & Broadcast']"
        self.maxRate="(//i[@class='a-icon a-icon-star-medium a-star-medium-4'])"
        self.lowPrice="//input[@name='low-price']"
        self.maxPrice="//input[@name='high-price']"
        self.go="//span[contains(text(),'Go') and @id='a-autoid-1-announce']"
        self.paperKinderCheck="//*[text()='Kindle eBooks']"
        self.paperHardCoverCheck="//*[text()='Hardcover']"
        self.panel="//*[@id='s-refinements']"
        self.bookTitle="(//div[@class='s-include-content-margin s-border-bottom'])[1]//a[@class='a-link-normal a-text-normal']//span"


    def selecting_sub_departments(self,driver):
        elementLocatorHelper = ElementLocatorHelpers(self)
        # driver.instance.implicitly_wait(200)
        # time.sleep(30)
        elementLocatorHelper.elementClick(driver, "xpath", self.paperBackCheck)
        # driver.instance.implicitly_wait(200)
        time.sleep(1)
        elementLocatorHelper.elementClick(driver, "xpath", self.seeMoreClick)
        # driver.instance.implicitly_wait(100)
        # time.sleep(1)
        elementLocatorHelper.elementClick(driver, "xpath", self.subDept)
        # driver.instance.implicitly_wait(100)
        time.sleep(1)
        elementLocatorHelper.elementClick(driver, "xpath", self.seeMoreClick)
        # driver.instance.implicitly_wait(100)
        # time.sleep(30)
        elementLocatorHelper.elementClick(driver, "xpath", self.nextSubDept)
        # time.sleep(30)
        # driver.instance.implicitly_wait(100)
        elementLocatorHelper.elementClick(driver, "xpath", self.paperKinderCheck)
        # driver.instance.implicitly_wait(100)
        # time.sleep(30)
        elementLocatorHelper.elementClick(driver, "xpath", self.paperHardCoverCheck)

    def selecting_high_rating(self,driver):
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementClick(driver, "xpath", self.maxRate)

    def priceSelector(self,driver,maxPrice,minPrice):
        elementLocatorHelper = ElementLocatorHelpers(self)
        elementLocatorHelper.elementsendKey(driver, "xpath", self.maxPrice,maxPrice)
        elementLocatorHelper.elementsendKey(driver, "xpath", self.lowPrice, minPrice)
        # elementLocatorHelper.elementClick(driver, "xpath", self.panel)
        elementLocatorHelper.elementSubmit(driver, "xpath", self.go)

    def storeResult(self,driver):
        elementLocatorHelper = ElementLocatorHelpers(self)
        file_handler=FileHandler(self);
        list=[]
        title=elementLocatorHelper.getText(driver,"xpath",self.bookTitle)
        print("READING TITLE FROM TEST1"+title)
        list.append(title)
        file_handler.write_into_file(self,list)

    def validateResult(self,driver):
        elementLocatorHelper = ElementLocatorHelpers(self)
        file_handler=FileHandler(self);
        list=file_handler.read_from_file(self);
        title = elementLocatorHelper.getText(driver, "xpath", self.bookTitle)
        print("READING TITLE FROM TEST2"+title)
        assert title==list[0],"Title doees not match"